@echo off
setlocal
cd /d "%~dp0"
set PORT=%1
if "%PORT%"=="" set PORT=8080
echo OurBackyard offline package
echo Serving: http://localhost:%PORT%
echo Press Ctrl+C to stop
py -3 -m http.server %PORT%
if errorlevel 1 python -m http.server %PORT%
endlocal
