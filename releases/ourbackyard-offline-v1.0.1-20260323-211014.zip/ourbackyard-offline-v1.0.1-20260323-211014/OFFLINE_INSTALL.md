# OurBackyard Offline Package

This package is self-contained and does not require `node_modules`.

## Windows
1. Double-click `start-local.bat`
2. Open [http://localhost:8080](http://localhost:8080)

## Linux / macOS
1. Run `./start-local.sh`
2. Open [http://localhost:8080](http://localhost:8080)

## Notes
- This is a decentralized client runtime package.
- No central backend is required for core P2P flow.
- Optional TURN config is in `ice-servers.json`.
